# mada-practical-02-apoorva1823000
mada-practical-02-apoorva1823000 created by GitHub Classroom<br>
This is practical 02 of MADA Subject of 6th sem SPCE Computer Engineering branch A1 batch<br><hr>
<b>AIM</b>:-Create an app and add two Button elements and a TextView to the layout. Implement click-handler methods to display messages on the screen when the user taps each Button.
<br><hr>
